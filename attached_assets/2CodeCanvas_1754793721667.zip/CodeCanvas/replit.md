# Overview

This is a comprehensive kindergarten management system for "روضة قطر الندى الأهلية" (Qatar Al-Nada National Kindergarten) built with Python and Streamlit. The system includes student registration, financial management (income/expenses), reporting, administrative functions, and automatic backup system. It features a complete Arabic interface with login system and transaction logging.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Primary Interface**: Streamlit web application providing a modern, responsive UI
- **Alternative Interface**: PyQt5 desktop application (legacy/backup interface)
- **Layout**: Multi-page navigation system with sidebar menu for easy access to different sections
- **Language Support**: Arabic language interface with right-to-left text support

## Backend Architecture
- **Framework**: Python-based application using Streamlit for web serving
- **Database Layer**: SQLite database with direct SQL operations
- **Modular Design**: Separated concerns with distinct modules:
  - `app.py`: Main application and dashboard
  - `db.py`: Database operations and schema management
  - `register.py`: Student registration functionality
- **Data Processing**: Real-time calculations for metrics like daily/monthly income

## Database Design
- **Database**: SQLite (`kindergarten.db`) for local data storage
- **Schema**: Single `students` table with comprehensive student information
- **Fields**: Student demographics, contact info, fee structure, and registration tracking
- **Auto-generation**: Database and tables created automatically on startup

## Key Features
- **Enhanced Dashboard**: Real-time analytics with visual progress indicators and quick actions
- **Student Registration**: Advanced form with validation, organized sections, and summary display  
- **Student Management**: Comprehensive list with search, filtering, and export capabilities
- **Expense Management**: Complete expense tracking system with daily summaries
- **Financial Reports**: Detailed reports showing income, expenses, and net profit with performance analysis
- **Data Export**: CSV export functionality for all student data
- **Multi-language**: Full Arabic interface with proper right-to-left text direction
- **Professional Design**: Modern UI with glassmorphism effects, animations, and gradient themes
- **Logo Integration**: Official kindergarten logo centered throughout all interface elements
- **Visual Effects**: Floating animations, pulse effects, and interactive hover states

# External Dependencies

## Core Libraries
- **streamlit**: Web application framework for the main interface
- **pandas**: Data manipulation and analysis (imported but usage not shown in provided code)
- **sqlite3**: Built-in Python database interface
- **datetime**: Date and time handling for registration tracking

## Desktop Application Dependencies
- **PyQt5**: GUI framework for desktop interface components
  - QtWidgets: UI components and layouts
  - QtGui: Graphics and fonts
  - QtCore: Core functionality and date handling

## Database
- **SQLite**: Embedded database for local data storage, no external database server required
- **File-based**: Database stored as local file (`kindergarten.db`)